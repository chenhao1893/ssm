CREATE procedure pp(empno emp.empno%type)
as
-- 声明变量部分

begin
  update emp set sal = sal+100 where emp.empno = empno;
end;
/

