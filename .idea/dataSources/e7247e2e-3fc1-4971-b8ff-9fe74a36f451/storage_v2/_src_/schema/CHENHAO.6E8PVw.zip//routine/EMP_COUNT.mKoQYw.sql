CREATE function emp_count(eno emp.empno%type) return number as
  co number(6);
begin
  select sal * 12 + nvl(comm, 0)
    into co
    from emp
   where empno = eno;
  return co;
end;
/

