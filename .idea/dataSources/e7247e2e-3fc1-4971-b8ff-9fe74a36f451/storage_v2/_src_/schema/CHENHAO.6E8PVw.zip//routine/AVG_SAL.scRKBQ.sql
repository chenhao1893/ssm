CREATE function avg_sal(deno emp.deptno%type) return number as
   avg_sal emp.deptno%type;
begin
  select avg(sal) into avg_sal from emp where emp.deptno=deno;
  return avg_sal;
end;
/

